# Uzupełnienie BOM dla wszystkich komponentów STS

## Cel

Rozszerzyć generowanie BOM tak, aby obejmowało wszystkie pozycje komponentów możliwe do dodania w formularzu STS oraz żeby nazwy komponentów były spójne, standardowe i łatwe do wyceny w cenniku.

## Zakres zmian

- Przeanalizować wszystkie sekcje formularza STS, w których użytkownik dodaje lub wybiera komponenty.
- Uzupełnić BOM o brakujące pozycje z obudowy, fundamentu, drzwi, wentylacji, układów pomiarowych, SPW, sterowników, analizatorów, modemów, wyposażenia dodatkowego, transformatorów, rozdzielnicy SN, rozdzielnicy nN, TPW, przekładników, aparatów, kabli, badań, transportu i uruchomienia.
- Ustandaryzować pole „Nazwa standardowa” w BOM tak, aby podobne komponenty zawsze trafiały pod tę samą nazwę niezależnie od miejsca w formularzu.
- Zachować szczegóły techniczne w polu „Szczegóły”, zamiast mieszać je z nazwą standardową.
- Zachować obecny układ aplikacji: STS, BOM, Cennik i Oferta pozostają w istniejących zakładkach.

## Decyzje użytkowe

- BOM ma być generowany automatycznie z aktualnych danych STS.
- Nazwy standardowe mają służyć do dopasowania pozycji z cennikiem.
- Parametry wariantowe, takie jak napięcie, prąd, lokalizacja, liczba rdzeni, RAL, uwagi i konfiguracje, mają pozostać w szczegółach pozycji.
- Pozycje wielokrotne mają się sumować, gdy mają tę samą kategorię, nazwę standardową i zgodne szczegóły.

## Obszary komponentów do objęcia BOM

- Dane i konfiguracja stacji
- Obudowa stacji
- Moduły obudowy
- Fundament i przepusty kablowe
- Drzwi i kratki wentylacyjne
- Wentylacja mechaniczna i grawitacyjna
- Połączenia kablowe wewnętrzne
- Układy pomiarowe
- Szafy SPW
- Sterowniki polowe
- Analizatory SN
- Modemy komunikacyjne
- Wyposażenie dodatkowe
- Transformatory
- Akcesoria transformatora
- Rozdzielnica SN
- Pola SN i wyposażenie pól
- TPW
- Przekładniki prądowe i napięciowe SN
- Rozdzielnica nN
- Aparat zasilający nN
- Aparaty dodatkowe nN
- Przekładniki prądowe i napięciowe nN
- Wyposażenie rozdzielnicy nN
- Odpływy nN, wkładki, przekroje i prądy
- FAT, SAT i badania powykonawcze
- Transport, montaż, projekt, rozruch i usługi budowlane

## Standaryzacja nazw

- Wprowadzić wspólne reguły nazewnictwa dla BOM.
- Nazwa standardowa ma być krótka i powtarzalna, np. „Transformator olejowy”, „Rozdzielnica SN — pole liniowe”, „Przekładnik prądowy SN”, „Wentylator dachowy”, „Szafa SPW”.
- Opis konfiguracji ma trafiać do szczegółów, np. producent, model, napięcie, prąd, lokalizacja, ilość, typ pola, wymagania dodatkowe.
- Cennik ma dalej dopasowywać ceny po nazwie standardowej.

## Co zostaje bez zmian

- Istniejący formularz STS i jego pola.
- Istniejące zakładki aplikacji.
- Istniejący cennik komponentów.
- Obecna logika ręcznego dodawania i aktualizacji cen w zakładce Cennik.

## Efekt dla użytkownika

- Po wypełnieniu STS zakładka BOM pokaże pełniejszą listę komponentów do oferty.
- Wycena będzie stabilniejsza, bo podobne komponenty będą miały jednolite nazwy.
- Szczegóły techniczne pozostaną widoczne bez rozbijania dopasowania do cennika.