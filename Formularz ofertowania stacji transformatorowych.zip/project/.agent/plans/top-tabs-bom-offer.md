# Plan: Górny pasek kart STS, BOM i Oferta

## Cel
- Dodać u górnej części aplikacji pasek kart pozwalający przełączać się między STS, BOM i ofertą generowaną na podstawie STS.

## Zakres zmian
- Zachować obecną kartę/formularz STS jako pierwszą zakładkę.
- Dodać drugą zakładkę BOM pokazującą zestawienie elementów wynikające z aktualnych danych STS.
- Dodać trzecią zakładkę Oferta pokazującą ofertę wygenerowaną z danych STS i pozycji BOM.
- Pasek kart ma być widoczny u góry i umożliwiać szybkie przechodzenie między widokami bez utraty danych wpisanych w STS.

## Widoki
- STS: obecny formularz konfiguracji pozostaje głównym miejscem edycji danych.
- BOM: czytelna lista pozycji materiałowych z ilościami i grupami sprzętu.
- Oferta: uporządkowany podgląd oferty przygotowany na podstawie STS, gotowy do dalszej edycji lub eksportu w przyszłości.

## Co zostaje bez zmian
- Istniejące sekcje STS, listy urządzeń i logika wyboru wyposażenia.
- Obecne dane formularza i dotychczasowe elementy BOM.

## Decyzje użytkowe
- Nawigacja będzie miała formę prostego górnego paska kart: STS, BOM, Oferta.
- BOM i Oferta będą generowane z aktualnego stanu STS, żeby użytkownik nie musiał przepisywać danych ręcznie.
