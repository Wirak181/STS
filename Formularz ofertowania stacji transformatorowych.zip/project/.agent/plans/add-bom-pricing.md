# Dodanie cennika i cen w BOM

## Cel

Rozszerzyć formularz ofertowy o cennik komponentów utrzymywany w aplikacji oraz automatyczne pokazywanie cen przy pozycjach BOM.

## Zakres zmian

- Dodać zakładkę `Cennik` obok istniejących zakładek `STS`, `BOM` i `Oferta`.
- W zakładce `Cennik` umożliwić działowi zakupów przeglądanie i edycję pozycji cenowych.
- Dopasowywać pozycje BOM do cennika po `nazwie standardowej`.
- W BOM pokazywać cenę jednostkową, wartość pozycji i status ceny.
- Dodać podsumowanie wartości BOM: suma pozycji zweryfikowanych, suma pozycji do weryfikacji oraz liczba pozycji bez ceny.
- Zachować obecne generowanie BOM i istniejący układ formularza.

## Cennik

- Encja danych: `Pozycja cennika`.
- Widok listy pozycji cennika z nazwą standardową, kategorią, ceną jednostkową, walutą, statusem i datą aktualizacji.
- Edycja ceny, statusu i notatki zakupowej bez opuszczania zakładki.
- Statusy ceny: `brak ceny`, `do weryfikacji`, `zweryfikowana`.

## BOM

- Każda pozycja BOM próbuje znaleźć cenę w cenniku po tej samej nazwie standardowej.
- Pozycje bez dopasowania pokazują status `brak ceny` i pustą wartość.
- Pozycje z dopasowaniem, ale niezweryfikowane, pokazują status `do weryfikacji`.
- Pozycje zweryfikowane pokazują cenę i wartość w sposób wyróżniony jako gotowe do oferty.

## Decyzje użytkowe

- Utrzymanie cen odbywa się w aplikacji, nie przez import z Excela.
- Dopasowanie jest proste i czytelne: po nazwie standardowej komponentu.
- Proces akceptacji jest lekki: status ceny zamiast pełnej historii akceptacji.

## Dane

- Pozycja cennika

## Poza zakresem

- Import lub eksport cennika z Excela.
- Historia zmian cen i pełny audit trail.
- Automatyczne zapytania ofertowe do dostawców.
- Zaawansowane reguły wyceny po parametrach technicznych.