# Cennik komponentów głównych

## Cel
- Dodać w istniejącej aplikacji moduł cennika komponentów głównych, który pozwoli utrzymywać ceny transformatorów według parametrów technicznych i automatycznie dobierać cenę po konfiguracji oferty.

## Ważna decyzja produktowa
- Platforma obsługuje jeden app per project, więc zamiast osobnej zewnętrznej aplikacji powstanie osobna sekcja/strona „Cennik” w obecnej aplikacji ofertowej.
- Cennik będzie wydzielonym modułem, aby można go było traktować jako niezależne źródło danych dla konfiguratora.

## Zakres zmian
- Rozszerzyć model danych cennika komponentów o warianty transformatora.
- Dodać rekordy cennika dla transformatorów z parametrami: moc, napięcie pierwotne, napięcie wtórne, cena.
- Dodać stronę lub widok „Cennik” do przeglądania i edycji pozycji cennika komponentów głównych.
- Po konfiguracji transformatora w formularzu dobrać pasującą pozycję cennika i pokazać cenę w podsumowaniu/BOM.
- Gdy brak dokładnego dopasowania, pokazać status „brak ceny / do weryfikacji”, zamiast zgadywać cenę.

## Dane
- Cennik komponentów
- Wariant cennikowy transformatora
- Oferta

## Widoki i funkcje
- Cennik komponentów głównych — tabela pozycji z filtrami po kategorii, mocy i napięciach.
- Edycja pozycji cennika — formularz ceny transformatora dla kombinacji moc + napięcie pierwotne + napięcie wtórne.
- Formularz oferty — automatyczne dopasowanie ceny transformatora na podstawie wybranej konfiguracji.
- Podsumowanie/BOM — pokazanie dobranej ceny, statusu ceny i informacji, jeśli wymagana jest weryfikacja.

## Co zostaje bez zmian
- Obecny formularz konfiguracji oferty pozostaje głównym miejscem pracy użytkownika.
- Istniejące sekcje transformatora, rozdzielnic SN/nn, obudowy, testów i transportu pozostają w aplikacji.
- Istniejący cennik komponentów nadal będzie używany dla pozostałych komponentów BOM.

## Reguła doboru ceny
- Dopasowanie dokładne: moc transformatora + napięcie pierwotne + napięcie wtórne.
- Jeżeli istnieje jedna pasująca pozycja ze zweryfikowaną ceną, system używa jej w ofercie.
- Jeżeli nie ma dopasowania albo cena wymaga weryfikacji, system pokazuje komunikat do sprawdzenia.
