# Plan: dodatkowe pola konfiguracji transformatorów

## Zakres zmiany
- Rozszerzyć każdy konfigurowany transformator w sekcji „Część techniczna” o dodatkowe pola techniczne.
- Zachować istniejącą możliwość dodawania maksymalnie 4 transformatorów.
- Zachować dotychczasowe obliczanie prądu znamionowego strony wtórnej.

## Pola do dodania dla każdego transformatora
- Materiał
- Zastosowanie
- Rodzaj zabezpieczenia termicznego
- Ograniczniki przepięć
- Położenie termometru
- Dyrektywa
- Schemat połączeń
- THDi (%)
- Typ ZSN
- Ekrany elektrostatyczne
- Regulacja
- Dodatkowe uwagi do ręcznego uzupełnienia

## Decyzje użytkowe
- Pola techniczne będą częścią konfiguracji każdego pojedynczego transformatora, a nie globalnymi ustawieniami sekcji.
- „Dodatkowe uwagi” będzie polem tekstowym do ręcznego wpisania informacji niestandardowych.
- Układ formularza pozostanie spójny z obecną sekcją techniczną i nie zmieni wcześniejszych sekcji handlowych ani informacyjnych.

## Co pozostaje bez zmian
- Sekcje Informacje i Warunki handlowe.
- Numer oferty, rewizja, opiekun, dane użytkownika i daty.
- Limit maksymalnie 4 transformatorów.
- Automatyczne wyliczanie prądu wtórnego.