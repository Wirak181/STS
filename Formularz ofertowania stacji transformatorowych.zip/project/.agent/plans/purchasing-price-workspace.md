# Plan: moduł zakupowy do cen komponentów

## Cel

Rozszerzyć istniejącą aplikację o wydzieloną przestrzeń dla działu zakupów do utrzymywania cen komponentów, a w BOM wyświetlać aktualne ceny przy pozycjach.

## Ważna decyzja platformowa

- Platforma obsługuje jeden app w projekcie, więc zamiast osobnej zewnętrznej aplikacji plan zakłada jeden wspólny system z wydzielonym widokiem/zakładką dla zakupów.
- Dostęp zakupów może być rozwiązany jako osobna strona lub zakładka „Zakupy / Cennik”, ukryta z głównego procesu ofertowego dla użytkowników STS.

## Co się zmieni

- Przywrócić cennik jako osobną przestrzeń zakupową, nie jako zakładkę roboczą w głównym formularzu STS.
- Dodać widok dla działu zakupów do dodawania, edycji i aktualizacji cen komponentów.
- Połączyć BOM z tabelą cen po nazwie standardowej komponentu.
- W BOM pokazywać cenę jednostkową, wartość pozycji i status ceny.
- W ofercie zachować podsumowanie wartości BOM na podstawie aktualnych cen.

## Co zostaje bez zmian

- Formularz STS pozostaje głównym miejscem przygotowania specyfikacji technicznej.
- Generowanie BOM nadal bazuje na danych technicznych wpisanych w STS.
- Układ głównych zakładek STS, BOM i Oferta może pozostać prosty dla użytkowników ofertowania.

## Funkcje

- Widok „Zakupy”: lista komponentów z cenami, statusem i datą aktualizacji.
- Formularz ceny: dodanie nowej pozycji lub aktualizacja istniejącej ceny.
- Status ceny: brak ceny, do weryfikacji, zweryfikowana.
- BOM: automatyczne dopasowanie ceny do komponentu i oznaczenie braków cenowych.
- Podsumowanie BOM: suma netto i liczba pozycji bez ceny.

## Dane

- Cennik komponentów
- Oferta
- Pracownik

## Uprawnienia i dostęp

- Najprostsza wersja: osobna zakładka „Zakupy” w tej samej aplikacji.
- Docelowa wersja: widoczność sekcji zakupowej zależna od użytkownika lub roli, jeśli dostępne będą reguły ról/grup.

## Otwarte decyzje

- Czy ceny mają być importowane jednorazowo z arkusza, czy tylko przepisywane i utrzymywane ręcznie przez zakupy.
- Czy komponenty bez ceny w BOM mają automatycznie trafiać do kolejki „do wyceny” dla zakupów.
- Czy historia zmian cen jest wymagana, czy wystarczy aktualna cena i data aktualizacji.
