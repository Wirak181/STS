# Plan: Formularz ofertowania stacji transformatorowych

## Cel
- Aplikacja będzie estetycznym, jednoekranowym formularzem dla działu ofertowania do ręcznego uzupełniania danych stacji transformatorowych z listami rozwijanymi i podpowiedziami zależności.

## Zakres aplikacji
- Formularz danych ogólnych oferty dla stacji transformatorowej.
- Automatyczne generowanie kolejnego numeru oferty.
- Automatyczne wyznaczanie numeru rewizji przy korekcie dokumentu.
- Pobieranie zalogowanego użytkownika jako osoby „STS Przygotował”.
- Listy rozwijane dla opiekunów klienta i późniejszych parametrów technicznych.
- Podpowiedzi zależności między wybranymi parametrami formularza.
- Wizualnie dopracowany, profesjonalny interfejs dla pracy ofertowej.

## Dane ogólne na starcie formularza
- Oferta nr.
- Opiekun.
- Opiekun Telefon.
- Opiekun Mail.
- STS Przygotował.
- Telefon.
- Mail.
- Rewizja nr.
- Miejscowość.
- Data.

## Proponowane dane aplikacji
- Oferty.
- Rewizje ofert.
- Pracownicy.
- Parametry stacji transformatorowych.
- Reguły podpowiedzi.

## Do doprecyzowania podczas wdrożenia
- Pełna lista pracowników dostępnych w polu „Opiekun”.
- Reguły generowania numeru oferty, np. format roczny lub sekwencyjny.
- Reguły numerowania rewizji.
- Docelowe parametry techniczne stacji transformatorowych i zależności między nimi.
- Czy dane mają być tylko lokalne testowe, czy później powiązane z firmową bazą/listą.

## Strony i funkcje
- Formularz oferty: główny ekran z sekcją danych ogólnych, listami rozwijanymi i automatycznie uzupełnianymi polami.
- Panel podpowiedzi: boczna lub wyróżniona sekcja pokazująca zależności wynikające z wyborów użytkownika.
- Lista ostatnich ofert: kompaktowy podgląd ostatnio utworzonych ofert i rewizji.

## Projekt wizualny
- Profesjonalny styl techniczno-przemysłowy, inspirowany dokumentacją energetyczną i pulpitami inżynierskimi.
- Kolorystyka oparta o granat, stal i akcent energetyczny.
- Czytelne karty formularza, wyraźne statusy, minimalna liczba rozpraszających elementów.

## Co zostaje poza zakresem tej wersji
- Integracja z systemem ERP/CRM.
- Eksport PDF/Word, chyba że zostanie dopisany do planu.
- Wieloetapowy konfigurator techniczny, jeśli nie zostaną dostarczone konkretne zależności.