# Formularz ofertowy stacji transformatorowych

Aplikacja wspiera dział ofertowania w przygotowywaniu STS, BOM i danych do ofert na stacje transformatorowe. Dodatkowo zawiera wydzieloną przestrzeń zakupową do bieżącego utrzymywania cen komponentów, które są automatycznie widoczne w BOM.

## Użytkownicy

- Dział ofertowania: uzupełnia formularz STS, generuje BOM i sprawdza aktualne ceny komponentów przy pozycjach BOM.
- Dział zakupów: dodaje komponenty do cennika, aktualizuje ceny, statusy weryfikacji i uwagi zakupowe.
- Osoba przygotowująca STS: widzi swoje dane z kontekstu zalogowanego użytkownika i uzupełnia część techniczną.

## Zakres

- Informacje ogólne oferty: numer, opiekun, dane kontaktowe, przygotowujący, rewizja, miejscowość i data.
- Listy rozwijane dla pracowników, typów stacji, napięć, mocy i konfiguracji.
- BOM połączony z cennikiem komponentów po nazwie standardowej, z ceną jednostkową, wartością i statusem ceny.
- Widok Zakupy do ręcznego dodawania oraz edycji cen komponentów.

## Kierunek wizualny

Profesjonalny, techniczny interfejs w stylu przemysłowym: głęboki granat, energetyczny bursztyn, czytelne karty i uporządkowane sekcje formularza.