import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { KonfiguracjaRozdzielnicyService } from "../services/konfiguracja-rozdzielnicy-service";
import type { KonfiguracjaRozdzielnicy } from "../models/konfiguracja-rozdzielnicy-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all KonfiguracjaRozdzielnicy records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, konfiguracja, liczbaPl, opis, typRozdzielnicyKey
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useKonfiguracjaRozdzielnicyList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["konfiguracjaRozdzielnicy-list", options],
    queryFn: () => KonfiguracjaRozdzielnicyService.getAll(options),
  });
}

/**
 * Retrieve a single KonfiguracjaRozdzielnicy record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useKonfiguracjaRozdzielnicy(id: string) {
  return useQuery({
    queryKey: ["konfiguracjaRozdzielnicy", id],
    queryFn: () => KonfiguracjaRozdzielnicyService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new KonfiguracjaRozdzielnicy record.
 * @remarks Form validation: use CreateKonfiguracjaRozdzielnicySchema with zodResolver for type-safe create forms
 */
export function useCreateKonfiguracjaRozdzielnicy() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<KonfiguracjaRozdzielnicy, "id">) => KonfiguracjaRozdzielnicyService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["konfiguracjaRozdzielnicy-list"] });
    },
  });
}

/**
 * Update an existing KonfiguracjaRozdzielnicy record.
 * @remarks Form validation: use UpdateKonfiguracjaRozdzielnicySchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateKonfiguracjaRozdzielnicy() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<KonfiguracjaRozdzielnicy, "id">>;
    }) => KonfiguracjaRozdzielnicyService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["konfiguracjaRozdzielnicy-list"] });
      client.invalidateQueries({ queryKey: ["konfiguracjaRozdzielnicy", variables.id] });
    },
  });
}

/**
 * Delete a KonfiguracjaRozdzielnicy record by its unique identifier.
 */
export function useDeleteKonfiguracjaRozdzielnicy() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => KonfiguracjaRozdzielnicyService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["konfiguracjaRozdzielnicy-list"] });
      client.invalidateQueries({ queryKey: ["konfiguracjaRozdzielnicy", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const KonfiguracjaRozdzielnicy_DATA_SOURCE_TYPE = 'InMemory' as const;

export { KonfiguracjaRozdzielnicySchema, CreateKonfiguracjaRozdzielnicySchema, UpdateKonfiguracjaRozdzielnicySchema } from "../validators/konfiguracja-rozdzielnicy-validator";
export type { KonfiguracjaRozdzielnicyInput, CreateKonfiguracjaRozdzielnicyInput, UpdateKonfiguracjaRozdzielnicyInput } from "../validators/konfiguracja-rozdzielnicy-validator";