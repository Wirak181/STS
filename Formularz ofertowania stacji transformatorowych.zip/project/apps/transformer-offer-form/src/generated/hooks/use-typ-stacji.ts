import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { TypStacjiService } from "../services/typ-stacji-service";
import type { TypStacji } from "../models/typ-stacji-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all TypStacji records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, typStacji, opis
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useTypStacjiList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["typStacji-list", options],
    queryFn: () => TypStacjiService.getAll(options),
  });
}

/**
 * Retrieve a single TypStacji record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useTypStacji(id: string) {
  return useQuery({
    queryKey: ["typStacji", id],
    queryFn: () => TypStacjiService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new TypStacji record.
 * @remarks Form validation: use CreateTypStacjiSchema with zodResolver for type-safe create forms
 */
export function useCreateTypStacji() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<TypStacji, "id">) => TypStacjiService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["typStacji-list"] });
    },
  });
}

/**
 * Update an existing TypStacji record.
 * @remarks Form validation: use UpdateTypStacjiSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateTypStacji() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<TypStacji, "id">>;
    }) => TypStacjiService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["typStacji-list"] });
      client.invalidateQueries({ queryKey: ["typStacji", variables.id] });
    },
  });
}

/**
 * Delete a TypStacji record by its unique identifier.
 */
export function useDeleteTypStacji() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => TypStacjiService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["typStacji-list"] });
      client.invalidateQueries({ queryKey: ["typStacji", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const TypStacji_DATA_SOURCE_TYPE = 'InMemory' as const;

export { TypStacjiSchema, CreateTypStacjiSchema, UpdateTypStacjiSchema } from "../validators/typ-stacji-validator";
export type { TypStacjiInput, CreateTypStacjiInput, UpdateTypStacjiInput } from "../validators/typ-stacji-validator";