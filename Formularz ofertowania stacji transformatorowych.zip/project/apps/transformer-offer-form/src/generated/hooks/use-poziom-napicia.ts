import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PoziomNapiciaService } from "../services/poziom-napicia-service";
import type { PoziomNapicia } from "../models/poziom-napicia-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all PoziomNapicia records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, napicie, napicieZnamionoweKV, typNapiciaKey
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function usePoziomNapiciaList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["poziomNapicia-list", options],
    queryFn: () => PoziomNapiciaService.getAll(options),
  });
}

/**
 * Retrieve a single PoziomNapicia record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function usePoziomNapicia(id: string) {
  return useQuery({
    queryKey: ["poziomNapicia", id],
    queryFn: () => PoziomNapiciaService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new PoziomNapicia record.
 * @remarks Form validation: use CreatePoziomNapiciaSchema with zodResolver for type-safe create forms
 */
export function useCreatePoziomNapicia() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<PoziomNapicia, "id">) => PoziomNapiciaService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["poziomNapicia-list"] });
    },
  });
}

/**
 * Update an existing PoziomNapicia record.
 * @remarks Form validation: use UpdatePoziomNapiciaSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdatePoziomNapicia() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<PoziomNapicia, "id">>;
    }) => PoziomNapiciaService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["poziomNapicia-list"] });
      client.invalidateQueries({ queryKey: ["poziomNapicia", variables.id] });
    },
  });
}

/**
 * Delete a PoziomNapicia record by its unique identifier.
 */
export function useDeletePoziomNapicia() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => PoziomNapiciaService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["poziomNapicia-list"] });
      client.invalidateQueries({ queryKey: ["poziomNapicia", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const PoziomNapicia_DATA_SOURCE_TYPE = 'InMemory' as const;

export { PoziomNapiciaSchema, CreatePoziomNapiciaSchema, UpdatePoziomNapiciaSchema } from "../validators/poziom-napicia-validator";
export type { PoziomNapiciaInput, CreatePoziomNapiciaInput, UpdatePoziomNapiciaInput } from "../validators/poziom-napicia-validator";