export * from './use-pracownik';
export * from './use-typ-stacji';
export * from './use-moc-transformatora';
export * from './use-poziom-napicia';
export * from './use-konfiguracja-rozdzielnicy';
export * from './use-podpowied-techniczna';
export * from './use-oferta';
export * from './use-cennik-komponentw';

export const HAS_IN_MEMORY_TABLES = true as const;