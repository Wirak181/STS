import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PodpowiedTechnicznaService } from "../services/podpowied-techniczna-service";
import type { PodpowiedTechniczna } from "../models/podpowied-techniczna-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all PodpowiedTechniczna records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, nazwaPodpowiedzi, trePodpowiedzi, wanoKey
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function usePodpowiedTechnicznaList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["podpowiedTechniczna-list", options],
    queryFn: () => PodpowiedTechnicznaService.getAll(options),
  });
}

/**
 * Retrieve a single PodpowiedTechniczna record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function usePodpowiedTechniczna(id: string) {
  return useQuery({
    queryKey: ["podpowiedTechniczna", id],
    queryFn: () => PodpowiedTechnicznaService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new PodpowiedTechniczna record.
 * @remarks Form validation: use CreatePodpowiedTechnicznaSchema with zodResolver for type-safe create forms
 */
export function useCreatePodpowiedTechniczna() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<PodpowiedTechniczna, "id">) => PodpowiedTechnicznaService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["podpowiedTechniczna-list"] });
    },
  });
}

/**
 * Update an existing PodpowiedTechniczna record.
 * @remarks Form validation: use UpdatePodpowiedTechnicznaSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdatePodpowiedTechniczna() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<PodpowiedTechniczna, "id">>;
    }) => PodpowiedTechnicznaService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["podpowiedTechniczna-list"] });
      client.invalidateQueries({ queryKey: ["podpowiedTechniczna", variables.id] });
    },
  });
}

/**
 * Delete a PodpowiedTechniczna record by its unique identifier.
 */
export function useDeletePodpowiedTechniczna() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => PodpowiedTechnicznaService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["podpowiedTechniczna-list"] });
      client.invalidateQueries({ queryKey: ["podpowiedTechniczna", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const PodpowiedTechniczna_DATA_SOURCE_TYPE = 'InMemory' as const;

export { PodpowiedTechnicznaSchema, CreatePodpowiedTechnicznaSchema, UpdatePodpowiedTechnicznaSchema } from "../validators/podpowied-techniczna-validator";
export type { PodpowiedTechnicznaInput, CreatePodpowiedTechnicznaInput, UpdatePodpowiedTechnicznaInput } from "../validators/podpowied-techniczna-validator";