import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { PracownikService } from "../services/pracownik-service";
import type { Pracownik } from "../models/pracownik-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all Pracownik records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, imiINazwisko, email, rolaKey, telefon
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function usePracownikList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["pracownik-list", options],
    queryFn: () => PracownikService.getAll(options),
  });
}

/**
 * Retrieve a single Pracownik record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function usePracownik(id: string) {
  return useQuery({
    queryKey: ["pracownik", id],
    queryFn: () => PracownikService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new Pracownik record.
 * @remarks Form validation: use CreatePracownikSchema with zodResolver for type-safe create forms
 */
export function useCreatePracownik() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<Pracownik, "id">) => PracownikService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["pracownik-list"] });
    },
  });
}

/**
 * Update an existing Pracownik record.
 * @remarks Form validation: use UpdatePracownikSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdatePracownik() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<Pracownik, "id">>;
    }) => PracownikService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["pracownik-list"] });
      client.invalidateQueries({ queryKey: ["pracownik", variables.id] });
    },
  });
}

/**
 * Delete a Pracownik record by its unique identifier.
 */
export function useDeletePracownik() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => PracownikService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["pracownik-list"] });
      client.invalidateQueries({ queryKey: ["pracownik", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const Pracownik_DATA_SOURCE_TYPE = 'InMemory' as const;

export { PracownikSchema, CreatePracownikSchema, UpdatePracownikSchema } from "../validators/pracownik-validator";
export type { PracownikInput, CreatePracownikInput, UpdatePracownikInput } from "../validators/pracownik-validator";