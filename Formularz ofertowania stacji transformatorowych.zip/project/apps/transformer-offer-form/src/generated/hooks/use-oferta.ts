import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { OfertaService } from "../services/oferta-service";
import type { Oferta } from "../models/oferta-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all Oferta records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, nazwaOferty, dataOferty, dataUtworzenia, miejscowo, numerOferty, numerRewizji, statusKey
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useOfertaList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["oferta-list", options],
    queryFn: () => OfertaService.getAll(options),
  });
}

/**
 * Retrieve a single Oferta record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useOferta(id: string) {
  return useQuery({
    queryKey: ["oferta", id],
    queryFn: () => OfertaService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new Oferta record.
 * @remarks Form validation: use CreateOfertaSchema with zodResolver for type-safe create forms
 */
export function useCreateOferta() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<Oferta, "id">) => OfertaService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["oferta-list"] });
    },
  });
}

/**
 * Update an existing Oferta record.
 * @remarks Form validation: use UpdateOfertaSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateOferta() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<Oferta, "id">>;
    }) => OfertaService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["oferta-list"] });
      client.invalidateQueries({ queryKey: ["oferta", variables.id] });
    },
  });
}

/**
 * Delete a Oferta record by its unique identifier.
 */
export function useDeleteOferta() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => OfertaService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["oferta-list"] });
      client.invalidateQueries({ queryKey: ["oferta", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const Oferta_DATA_SOURCE_TYPE = 'InMemory' as const;

export { OfertaSchema, CreateOfertaSchema, UpdateOfertaSchema } from "../validators/oferta-validator";
export type { OfertaInput, CreateOfertaInput, UpdateOfertaInput } from "../validators/oferta-validator";