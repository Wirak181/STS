import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CennikKomponentwService } from "../services/cennik-komponentw-service";
import type { CennikKomponentw } from "../models/cennik-komponentw-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all CennikKomponentw records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, nazwaStandardowa, cenaJednostkowaNettoPLN, dataAktualizacji, kategoria, statusCenyKey, uwagiZakupw, zweryfikowa
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useCennikKomponentwList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["cennikKomponentw-list", options],
    queryFn: () => CennikKomponentwService.getAll(options),
  });
}

/**
 * Retrieve a single CennikKomponentw record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useCennikKomponentw(id: string) {
  return useQuery({
    queryKey: ["cennikKomponentw", id],
    queryFn: () => CennikKomponentwService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new CennikKomponentw record.
 * @remarks Form validation: use CreateCennikKomponentwSchema with zodResolver for type-safe create forms
 */
export function useCreateCennikKomponentw() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<CennikKomponentw, "id">) => CennikKomponentwService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["cennikKomponentw-list"] });
    },
  });
}

/**
 * Update an existing CennikKomponentw record.
 * @remarks Form validation: use UpdateCennikKomponentwSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateCennikKomponentw() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<CennikKomponentw, "id">>;
    }) => CennikKomponentwService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["cennikKomponentw-list"] });
      client.invalidateQueries({ queryKey: ["cennikKomponentw", variables.id] });
    },
  });
}

/**
 * Delete a CennikKomponentw record by its unique identifier.
 */
export function useDeleteCennikKomponentw() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => CennikKomponentwService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["cennikKomponentw-list"] });
      client.invalidateQueries({ queryKey: ["cennikKomponentw", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const CennikKomponentw_DATA_SOURCE_TYPE = 'InMemory' as const;

export { CennikKomponentwSchema, CreateCennikKomponentwSchema, UpdateCennikKomponentwSchema } from "../validators/cennik-komponentw-validator";
export type { CennikKomponentwInput, CreateCennikKomponentwInput, UpdateCennikKomponentwInput } from "../validators/cennik-komponentw-validator";