import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MocTransformatoraService } from "../services/moc-transformatora-service";
import type { MocTransformatora } from "../models/moc-transformatora-model";
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Retrieve all MocTransformatora records with optional filtering and sorting.
 * @param options Optional filtering and sorting options
 *   Available properties for sorting: id, moc, mocKVA
 *   Filtering supports OData syntax, e.g., "status eq 'active'"
 */
export function useMocTransformatoraList(options?: IOperationOptions) {
  return useQuery({
    queryKey: ["mocTransformatora-list", options],
    queryFn: () => MocTransformatoraService.getAll(options),
  });
}

/**
 * Retrieve a single MocTransformatora record by its unique identifier.
 * @param id The id of the record (must be a valid UUID)
 */
export function useMocTransformatora(id: string) {
  return useQuery({
    queryKey: ["mocTransformatora", id],
    queryFn: () => MocTransformatoraService.get(id),
    enabled: !!id && UUID_REGEX.test(id),
  });
}

/**
 * Create a new MocTransformatora record.
 * @remarks Form validation: use CreateMocTransformatoraSchema with zodResolver for type-safe create forms
 */
export function useCreateMocTransformatora() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (data: Omit<MocTransformatora, "id">) => MocTransformatoraService.create(data),
    onSuccess: () => {
      client.invalidateQueries({ queryKey: ["mocTransformatora-list"] });
    },
  });
}

/**
 * Update an existing MocTransformatora record.
 * @remarks Form validation: use UpdateMocTransformatoraSchema.partial().omit({ id: true }) with zodResolver for edit forms (matches changedFields input)
 */
export function useUpdateMocTransformatora() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      changedFields,
    }: {
      id: string;
      changedFields: Partial<Omit<MocTransformatora, "id">>;
    }) => MocTransformatoraService.update(id, changedFields),
    onSuccess: (_data, variables) => {
      client.invalidateQueries({ queryKey: ["mocTransformatora-list"] });
      client.invalidateQueries({ queryKey: ["mocTransformatora", variables.id] });
    },
  });
}

/**
 * Delete a MocTransformatora record by its unique identifier.
 */
export function useDeleteMocTransformatora() {
  const client = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => MocTransformatoraService.delete(id),
    onSuccess: (_data, id) => {
      client.invalidateQueries({ queryKey: ["mocTransformatora-list"] });
      client.invalidateQueries({ queryKey: ["mocTransformatora", id] });
    },
  });
}

/** Data source type for this table — drives InMemoryDataBanner visibility. */
export const MocTransformatora_DATA_SOURCE_TYPE = 'InMemory' as const;

export { MocTransformatoraSchema, CreateMocTransformatoraSchema, UpdateMocTransformatoraSchema } from "../validators/moc-transformatora-validator";
export type { MocTransformatoraInput, CreateMocTransformatoraInput, UpdateMocTransformatoraInput } from "../validators/moc-transformatora-validator";