import { getClient } from '../../../app-gen-sdk/data';
import type { MocTransformatora } from '../models/moc-transformatora-model';
import type { IOperationOptions } from '../../../app-gen-sdk/data/common/types';

const DATA_SOURCE_NAME = 'MocTransformatora';

export class MocTransformatoraService {
  static async create(record: Omit<MocTransformatora, 'id'>): Promise<MocTransformatora> {
    const result = await getClient().createRecordAsync(DATA_SOURCE_NAME, record);
    if (!result.success) throw result.error;
    return result.data as MocTransformatora;
  }

  static async update(
    id: string,
    changedFields: Partial<Omit<MocTransformatora, 'id'>>
  ): Promise<MocTransformatora> {
    const result = await getClient().updateRecordAsync(DATA_SOURCE_NAME, id, changedFields);
    if (!result.success) throw result.error;
    return result.data as MocTransformatora;
  }

  static async delete(id: string): Promise<void> {
    const result = await getClient().deleteRecordAsync(DATA_SOURCE_NAME, id);
    if (!result.success) throw result.error;
  }

  static async get(id: string): Promise<MocTransformatora> {
    const result = await getClient().retrieveRecordAsync(DATA_SOURCE_NAME, id);
    if (!result.success) throw result.error;
    return result.data as MocTransformatora;
  }

  static async getAll(options?: IOperationOptions): Promise<MocTransformatora[]> {
    const result = await getClient().retrieveMultipleRecordsAsync(DATA_SOURCE_NAME, options);
    if (!result.success) throw result.error;
    return result.data as MocTransformatora[];
  }
}