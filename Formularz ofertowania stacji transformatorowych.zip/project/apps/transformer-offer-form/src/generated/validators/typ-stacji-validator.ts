import { z } from 'zod';

/**
 * Zod schema for TypStacji validation
 */
export const TypStacjiSchema = z.object({
  id: z.string().uuid(),
  typStacji: z.string().min(1, { message: "Typ stacji is required" }),
  opis: z.string().optional(),
});

/**
 * Schema for creating a new TypStacji (omits system-generated ID)
 */
export const CreateTypStacjiSchema = TypStacjiSchema.omit({ id: true });

/**
 * Schema for updating an existing TypStacji
 */
export const UpdateTypStacjiSchema = TypStacjiSchema;

export type TypStacjiInput = z.infer<typeof TypStacjiSchema>;
export type CreateTypStacjiInput = z.infer<typeof CreateTypStacjiSchema>;
export type UpdateTypStacjiInput = z.infer<typeof UpdateTypStacjiSchema>;