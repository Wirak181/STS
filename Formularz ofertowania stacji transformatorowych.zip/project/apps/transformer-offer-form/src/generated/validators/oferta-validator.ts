import { z } from 'zod';

/**
 * Zod schema for Oferta validation
 */
export const OfertaSchema = z.object({
  id: z.string().uuid(),
  nazwaOferty: z.string().min(1, { message: "Nazwa oferty is required" }),
  dataOferty: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format").min(1, { message: "Data oferty is required" }),
  dataUtworzenia: z.string().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/, "DateTime must be in ISO format").min(1, { message: "Data utworzenia is required" }),
  konfiguracjaRozdzielnicyNn: z.object({ id: z.string().uuid(), konfiguracja: z.string() }),
  konfiguracjaRozdzielnicySN: z.object({ id: z.string().uuid(), konfiguracja: z.string() }),
  miejscowo: z.string().min(1, { message: "Miejscowość is required" }),
  mocTransformatora: z.object({ id: z.string().uuid(), moc: z.string() }),
  napicieNn: z.object({ id: z.string().uuid(), napicie: z.string() }),
  napicieSN: z.object({ id: z.string().uuid(), napicie: z.string() }),
  numerOferty: z.string().min(1, { message: "Numer oferty is required" }),
  numerRewizji: z.number().int(),
  opiekunKlienta: z.object({ id: z.string().uuid(), imiINazwisko: z.string() }),
  statusKey: z.enum(['Robocza', 'Gotowa', 'Wysłana', 'Zarchiwizowana']),
  typStacji: z.object({ id: z.string().uuid(), typStacji: z.string() }),
});

/**
 * Schema for creating a new Oferta (omits system-generated ID)
 */
export const CreateOfertaSchema = OfertaSchema.omit({ id: true });

/**
 * Schema for updating an existing Oferta
 */
export const UpdateOfertaSchema = OfertaSchema;

export type OfertaInput = z.infer<typeof OfertaSchema>;
export type CreateOfertaInput = z.infer<typeof CreateOfertaSchema>;
export type UpdateOfertaInput = z.infer<typeof UpdateOfertaSchema>;