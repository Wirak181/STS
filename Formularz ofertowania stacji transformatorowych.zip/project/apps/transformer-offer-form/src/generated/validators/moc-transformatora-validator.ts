import { z } from 'zod';

/**
 * Zod schema for MocTransformatora validation
 */
export const MocTransformatoraSchema = z.object({
  id: z.string().uuid(),
  moc: z.string().min(1, { message: "Moc is required" }),
  mocKVA: z.number().int(),
});

/**
 * Schema for creating a new MocTransformatora (omits system-generated ID)
 */
export const CreateMocTransformatoraSchema = MocTransformatoraSchema.omit({ id: true });

/**
 * Schema for updating an existing MocTransformatora
 */
export const UpdateMocTransformatoraSchema = MocTransformatoraSchema;

export type MocTransformatoraInput = z.infer<typeof MocTransformatoraSchema>;
export type CreateMocTransformatoraInput = z.infer<typeof CreateMocTransformatoraSchema>;
export type UpdateMocTransformatoraInput = z.infer<typeof UpdateMocTransformatoraSchema>;