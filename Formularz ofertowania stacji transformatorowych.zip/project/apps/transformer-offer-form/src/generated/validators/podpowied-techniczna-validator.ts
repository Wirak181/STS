import { z } from 'zod';

/**
 * Zod schema for PodpowiedTechniczna validation
 */
export const PodpowiedTechnicznaSchema = z.object({
  id: z.string().uuid(),
  nazwaPodpowiedzi: z.string().min(1, { message: "Nazwa podpowiedzi is required" }),
  mocTransformatora: z.object({ id: z.string().uuid(), moc: z.string() }).optional(),
  napicieNn: z.object({ id: z.string().uuid(), napicie: z.string() }).optional(),
  napicieSN: z.object({ id: z.string().uuid(), napicie: z.string() }).optional(),
  trePodpowiedzi: z.string().min(1, { message: "Treść podpowiedzi is required" }),
  typStacji: z.object({ id: z.string().uuid(), typStacji: z.string() }).optional(),
  wanoKey: z.enum(['Informacja', 'Ostrzeżenie', 'WymaganeSprawdzenie']),
});

/**
 * Schema for creating a new PodpowiedTechniczna (omits system-generated ID)
 */
export const CreatePodpowiedTechnicznaSchema = PodpowiedTechnicznaSchema.omit({ id: true });

/**
 * Schema for updating an existing PodpowiedTechniczna
 */
export const UpdatePodpowiedTechnicznaSchema = PodpowiedTechnicznaSchema;

export type PodpowiedTechnicznaInput = z.infer<typeof PodpowiedTechnicznaSchema>;
export type CreatePodpowiedTechnicznaInput = z.infer<typeof CreatePodpowiedTechnicznaSchema>;
export type UpdatePodpowiedTechnicznaInput = z.infer<typeof UpdatePodpowiedTechnicznaSchema>;