import { z } from 'zod';

/**
 * Zod schema for Pracownik validation
 */
export const PracownikSchema = z.object({
  id: z.string().uuid(),
  imiINazwisko: z.string().min(1, { message: "Imię i nazwisko is required" }),
  email: z.string().email().min(1, { message: "Email is required" }),
  przeoony: z.object({ id: z.string().uuid(), imiINazwisko: z.string() }).optional(),
  rolaKey: z.enum(['Administrator', 'OpiekunKlienta', 'InżynierOfertowania']),
  telefon: z.string().optional(),
});

/**
 * Schema for creating a new Pracownik (omits system-generated ID)
 */
export const CreatePracownikSchema = PracownikSchema.omit({ id: true });

/**
 * Schema for updating an existing Pracownik
 */
export const UpdatePracownikSchema = PracownikSchema;

export type PracownikInput = z.infer<typeof PracownikSchema>;
export type CreatePracownikInput = z.infer<typeof CreatePracownikSchema>;
export type UpdatePracownikInput = z.infer<typeof UpdatePracownikSchema>;