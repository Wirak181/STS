import { z } from 'zod';

/**
 * Zod schema for KonfiguracjaRozdzielnicy validation
 */
export const KonfiguracjaRozdzielnicySchema = z.object({
  id: z.string().uuid(),
  konfiguracja: z.string().min(1, { message: "Konfiguracja is required" }),
  liczbaPl: z.number().int(),
  opis: z.string().optional(),
  typRozdzielnicyKey: z.enum(['SN', 'Nn']),
});

/**
 * Schema for creating a new KonfiguracjaRozdzielnicy (omits system-generated ID)
 */
export const CreateKonfiguracjaRozdzielnicySchema = KonfiguracjaRozdzielnicySchema.omit({ id: true });

/**
 * Schema for updating an existing KonfiguracjaRozdzielnicy
 */
export const UpdateKonfiguracjaRozdzielnicySchema = KonfiguracjaRozdzielnicySchema;

export type KonfiguracjaRozdzielnicyInput = z.infer<typeof KonfiguracjaRozdzielnicySchema>;
export type CreateKonfiguracjaRozdzielnicyInput = z.infer<typeof CreateKonfiguracjaRozdzielnicySchema>;
export type UpdateKonfiguracjaRozdzielnicyInput = z.infer<typeof UpdateKonfiguracjaRozdzielnicySchema>;