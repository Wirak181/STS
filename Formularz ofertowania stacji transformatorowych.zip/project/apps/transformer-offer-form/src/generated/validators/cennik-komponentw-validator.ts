import { z } from 'zod';

/**
 * Zod schema for CennikKomponentw validation
 */
export const CennikKomponentwSchema = z.object({
  id: z.string().uuid(),
  nazwaStandardowa: z.string().min(1, { message: "Nazwa standardowa is required" }),
  cenaJednostkowaNettoPLN: z.number().optional(),
  dataAktualizacji: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format").optional(),
  kategoria: z.string().optional(),
  statusCenyKey: z.enum(['BrakCeny', 'DoWeryfikacji', 'Zweryfikowana']),
  uwagiZakupw: z.string().optional(),
  zweryfikowa: z.string().email().optional(),
});

/**
 * Schema for creating a new CennikKomponentw (omits system-generated ID)
 */
export const CreateCennikKomponentwSchema = CennikKomponentwSchema.omit({ id: true });

/**
 * Schema for updating an existing CennikKomponentw
 */
export const UpdateCennikKomponentwSchema = CennikKomponentwSchema;

export type CennikKomponentwInput = z.infer<typeof CennikKomponentwSchema>;
export type CreateCennikKomponentwInput = z.infer<typeof CreateCennikKomponentwSchema>;
export type UpdateCennikKomponentwInput = z.infer<typeof UpdateCennikKomponentwSchema>;