import { z } from 'zod';

/**
 * Zod schema for PoziomNapicia validation
 */
export const PoziomNapiciaSchema = z.object({
  id: z.string().uuid(),
  napicie: z.string().min(1, { message: "Napięcie is required" }),
  napicieZnamionoweKV: z.number(),
  typNapiciaKey: z.enum(['SN', 'Nn']),
});

/**
 * Schema for creating a new PoziomNapicia (omits system-generated ID)
 */
export const CreatePoziomNapiciaSchema = PoziomNapiciaSchema.omit({ id: true });

/**
 * Schema for updating an existing PoziomNapicia
 */
export const UpdatePoziomNapiciaSchema = PoziomNapiciaSchema;

export type PoziomNapiciaInput = z.infer<typeof PoziomNapiciaSchema>;
export type CreatePoziomNapiciaInput = z.infer<typeof CreatePoziomNapiciaSchema>;
export type UpdatePoziomNapiciaInput = z.infer<typeof UpdatePoziomNapiciaSchema>;